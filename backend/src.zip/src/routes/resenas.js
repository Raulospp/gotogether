const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { pool } = require('../config');

// GET /api/resenas/:userId — reseñas de un usuario
router.get('/:userId', auth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(`
      SELECT r.id, r.calificacion, r.comentario, r.created_at,
             r.autor_id,
             u.name as autor_name, u.role as autor_role
      FROM resenas r
      JOIN users u ON u.id = r.autor_id
      WHERE r.receptor_id = $1
      ORDER BY r.created_at DESC
    `, [req.params.userId]);
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/resenas/:userId/promedio
router.get('/:userId/promedio', auth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(`
      SELECT ROUND(AVG(calificacion)::numeric, 1) as promedio,
             COUNT(*) as total
      FROM resenas
      WHERE receptor_id = $1
    `, [req.params.userId]);
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// POST /api/resenas — crear reseña
router.post('/', auth, async (req, res, next) => {
  try {
    const { receptor_id, calificacion, comentario, viaje_id } = req.body;
    const autor_id = req.user.id;

    if (autor_id === Number(receptor_id))
      return res.status(400).json({ message: 'No puedes reseñarte a ti mismo' });

    if (!calificacion || calificacion < 1 || calificacion > 5)
      return res.status(400).json({ message: 'Calificación debe ser entre 1 y 5' });

    // Verificar que compartieron un viaje
    const shared = await pool.query(`
      SELECT s.id FROM solicitudes s
      WHERE s.estado IN ('aceptada','en_curso','finalizada')
        AND (
          (s.pasajero_id = $1 AND s.conductor_id = $2) OR
          (s.pasajero_id = $2 AND s.conductor_id = $1)
        )
      LIMIT 1
    `, [autor_id, receptor_id]);

    if (shared.rows.length === 0)
      return res.status(403).json({ message: 'Solo puedes reseñar a usuarios con quienes compartiste un viaje' });

    // Evitar duplicado por viaje
    if (viaje_id) {
      const dup = await pool.query(
        'SELECT id FROM resenas WHERE autor_id = $1 AND receptor_id = $2 AND viaje_id = $3',
        [autor_id, receptor_id, viaje_id]
      );
      if (dup.rows.length > 0)
        return res.status(409).json({ message: 'Ya dejaste una reseña para este viaje' });
    }

    const { rows } = await pool.query(
      'INSERT INTO resenas (autor_id, receptor_id, calificacion, comentario, viaje_id) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [autor_id, receptor_id, calificacion, comentario || null, viaje_id || null]
    );

    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

module.exports = router;