<template>
  <ion-page>
    <ion-content :fullscreen="true" class="home-content">
      <div class="grain"></div>
      <div class="atm-glow"></div>

      <div class="top-bar">
        <div class="brand-name"><span class="go">go</span><span class="tog">Together</span></div>
        <button class="icon-btn" @click="handleLogout"><ion-icon :icon="logOutOutline" /></button>
      </div>

      <div class="profile-hero">
        <div class="avatar-wrap" @click="triggerPhotoUpload">
          <img v-if="profilePhoto" :src="profilePhoto" class="avatar-img" />
          <div v-else class="avatar">{{ userInitial }}</div>
          <div class="avatar-badge"><ion-icon :icon="cameraOutline" /></div>
          <input ref="photoInput" type="file" accept="image/*" style="display:none" @change="onPhotoChange" />
        </div>
        <div class="stats-row">
          <div class="stat"><span class="stat-n">0</span><span class="stat-l">Viajes</span></div>
          <div v-if="isConductor" class="stat"><span class="stat-n">{{ reviews.length }}</span><span class="stat-l">Reseñas</span></div>
          <div v-if="isConductor && reviews.length > 0" class="stat"><span class="stat-n">{{ avgRating }}</span><span class="stat-l">Rating</span></div>
          <div v-if="!isConductor" class="stat"><span class="stat-n">{{ user?.university || '—' }}</span><span class="stat-l">Uni</span></div>
        </div>
      </div>

      <div class="profile-meta">
        <div class="meta-name-row">
          <span class="meta-name">{{ user?.name }}</span>
          <span class="badge" :class="isConductor ? 'badge-red' : 'badge-gray'">
            <ion-icon :icon="isConductor ? carOutline : personOutline" />
            {{ isConductor ? 'Conductor' : 'Pasajero' }}
          </span>
        </div>
        <div class="meta-city"><ion-icon :icon="locationOutline" />{{ user?.city || '—' }}</div>
        <div v-if="!editingBio" class="bio-wrap" @click="editingBio = true">
          <p class="bio-text">{{ bio || '+ Agrega una descripción...' }}</p>
          <ion-icon :icon="createOutline" class="bio-edit-icon" />
        </div>
        <div v-else class="bio-edit">
          <textarea v-model="bio" placeholder="Cuéntanos sobre ti..." rows="3" @blur="saveBio" />
        </div>
        <button class="edit-profile-btn" @click="router.push('/editar-perfil')">Editar perfil</button>
      </div>

      <div class="tabs">
        <button v-for="tab in tabs" :key="tab.id" class="tab"
          :class="{ on: activeTab === tab.id }" @click="activeTab = tab.id">
          <ion-icon :icon="tab.icon" />
          <span>{{ tab.label }}</span>
        </button>
      </div>

      <!-- Info -->
      <div v-if="activeTab === 'info'" class="tab-content">
        <div class="info-card">
          <div class="info-row">
            <div class="info-icon-wrap"><ion-icon :icon="personOutline" /></div>
            <div class="info-col"><span class="info-lbl">Nombre</span><span class="info-val">{{ user?.name }}</span></div>
          </div>
          <div class="info-row">
            <div class="info-icon-wrap"><ion-icon :icon="mailOutline" /></div>
            <div class="info-col"><span class="info-lbl">Correo</span><span class="info-val">{{ user?.email }}</span></div>
          </div>
          <div v-if="!isConductor" class="info-row">
            <div class="info-icon-wrap"><ion-icon :icon="schoolOutline" /></div>
            <div class="info-col"><span class="info-lbl">Universidad</span><span class="info-val">{{ user?.university || '—' }}</span></div>
          </div>
          <div class="info-row">
            <div class="info-icon-wrap"><ion-icon :icon="locationOutline" /></div>
            <div class="info-col"><span class="info-lbl">Ciudad</span><span class="info-val">{{ user?.city || '—' }}</span></div>
          </div>
          <template v-if="isConductor">
            <div class="info-row">
              <div class="info-icon-wrap"><ion-icon :icon="carOutline" /></div>
              <div class="info-col"><span class="info-lbl">Vehículo</span><span class="info-val">{{ user?.car_model || '—' }}</span></div>
            </div>
            <div class="info-row">
              <div class="info-icon-wrap"><ion-icon :icon="cardOutline" /></div>
              <div class="info-col"><span class="info-lbl">Placa</span><span class="info-val">{{ user?.plate || '—' }}</span></div>
            </div>
            <div class="info-row">
              <div class="info-icon-wrap"><ion-icon :icon="speedometerOutline" /></div>
              <div class="info-col"><span class="info-lbl">Tipo</span><span class="info-val">{{ user?.vehicle_type === 'moto' ? 'Moto' : 'Carro' }}</span></div>
            </div>
          </template>
        </div>
      </div>

      <!-- Horarios -->
      <div v-if="activeTab === 'schedule'" class="tab-content">
        <p class="schedule-hint">Selecciona a qué hora sales y vuelves cada día. Se guarda automáticamente.</p>
        <div v-for="dia in dias" :key="dia.key" class="day-card">
          <button class="day-card-header" @click="toggleDia('schedule', dia.key)">
            <span class="day-name">{{ dia.label }}</span>
            <div class="day-chips">
              <span v-if="schedule[dia.key].ida" class="day-chip">↑ {{ schedule[dia.key].ida }}</span>
              <span v-if="schedule[dia.key].vuelta" class="day-chip">↓ {{ schedule[dia.key].vuelta }}</span>
              <span v-if="!schedule[dia.key].ida && !schedule[dia.key].vuelta" class="day-chip empty">Sin horario</span>
            </div>
            <ion-icon :icon="openDias.schedule[dia.key] ? chevronUpOutline : chevronDownOutline" class="day-chevron" />
          </button>
          <div v-if="openDias.schedule[dia.key]" class="day-card-body">
            <div class="day-field-row">
              <div class="day-field">
                <span class="day-field-label">↑ Ida</span>
                <select v-model="schedule[dia.key].ida" class="time-select" @change="autoSave(dia.key)">
                  <option value="">Sin horario</option>
                  <option v-for="h in horas" :key="h" :value="h">{{ h }}</option>
                </select>
              </div>
              <div class="day-field">
                <span class="day-field-label">↓ Vuelta</span>
                <select v-model="schedule[dia.key].vuelta" class="time-select" @change="autoSave(dia.key)">
                  <option value="">Sin horario</option>
                  <option v-for="h in horas" :key="h" :value="h">{{ h }}</option>
                </select>
              </div>
            </div>
            <div class="save-indicator" :class="{ visible: savedDia === dia.key }">
              <ion-icon :icon="checkmarkCircleOutline" /> ¡Guardado!
            </div>
          </div>
        </div>
      </div>

      <!-- Ruta -->
      <div v-if="activeTab === 'route'" class="tab-content">
        <div class="vehicle-card">
          <div class="vehicle-icon-wrap"><ion-icon :icon="carOutline" /></div>
          <div class="vehicle-info">
            <span class="vehicle-model">{{ user?.car_model || 'Vehículo no registrado' }}</span>
            <span class="vehicle-sub">{{ user?.plate || '— — —' }}</span>
          </div>
        </div>
        <div v-for="dia in dias" :key="dia.key" class="day-card">
          <button class="day-card-header" @click="toggleDia('route', dia.key)">
            <span class="day-name">{{ dia.label }}</span>
            <div class="day-chips">
              <span v-if="routes[dia.key].stops.filter((s:string) => s).length > 0" class="day-chip">
                {{ routes[dia.key].stops.filter((s:string) => s).length }} paradas
              </span>
              <span v-if="precio[dia.key]" class="day-chip" style="color:#4caf50">${{ precio[dia.key] }}</span>
            </div>
            <ion-icon :icon="openDias.route[dia.key] ? chevronUpOutline : chevronDownOutline" class="day-chevron" />
          </button>
          <div v-if="openDias.route[dia.key]" class="day-card-body">
            <div class="stops-list">
              <div v-for="(stop, i) in routes[dia.key].stops" :key="i" class="stop-row">
                <div class="stop-dot" :class="i === 0 ? 'start' : i === routes[dia.key].stops.length - 1 ? 'end' : 'mid'"></div>
                <input v-model="routes[dia.key].stops[i]" type="text"
                  :placeholder="i === 0 ? 'Punto de partida' : i === routes[dia.key].stops.length - 1 ? 'Destino final' : `Parada ${i}`"
                  class="stop-input" />
                <button v-if="routes[dia.key].stops.length > 2" class="btn-remove" @click="removeStop(dia.key, Number(i))">
                  <ion-icon :icon="closeOutline" />
                </button>
              </div>
            </div>


            <div class="precio-row">
              <span class="precio-label">
                <ion-icon :icon="cashOutline" /> Precio del viaje
              </span>
              <div class="precio-input-wrap">
                <span class="precio-currency">$</span>
                <input v-model="precio[dia.key]" type="number" placeholder="0" class="precio-input" min="0" />
              </div>
            </div>
            <div class="day-actions">
              <button class="btn-add" @click="addStop(dia.key)"><ion-icon :icon="addOutline" /> Parada</button>
              <button class="btn-save-sm" :class="{ saved: savedDia === dia.key }" @click="saveAndClose('route', dia.key)"><ion-icon :icon="savedDia === dia.key ? checkmarkCircleOutline : checkmarkOutline" /> {{ savedDia === dia.key ? '¡Guardado!' : 'Guardar' }}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Reseñas -->
      <div v-if="activeTab === 'reviews'" class="tab-content">
        <div v-if="reviews.length === 0" class="empty-state">
          <ion-icon :icon="starOutline" class="empty-icon" />
          <p>Aún no tienes reseñas</p>
        </div>
      </div>


      <!-- Nav Bar -->
      <div class="bottom-nav">
        <button class="nav-item" @click="router.push('/inicio')">
          <ion-icon :icon="homeOutline" />
          <span>Inicio</span>
        </button>
        <button class="nav-item" @click="router.push('/feed')">
          <ion-icon :icon="searchOutline" />
          <span>Explorar</span>
        </button>
        <button class="nav-item" @click="router.push('/solicitudes')">
          <ion-icon :icon="documentTextOutline" />
          <span>Solicitudes</span>
        </button>
        <button class="nav-item active">
          <ion-icon :icon="personOutline" />
          <span>Perfil</span>
          <div class="nav-dot"></div>
        </button>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed, reactive, watch, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { IonPage, IonContent, IonIcon } from '@ionic/vue';
import {
  logOutOutline, cameraOutline, createOutline, checkmarkOutline, checkmarkCircleOutline,
  addOutline, closeOutline, starOutline, carOutline, personOutline,
  mailOutline, schoolOutline, locationOutline, cardOutline, timeOutline,
  mapOutline, speedometerOutline, chevronUpOutline, chevronDownOutline, cashOutline,
  homeOutline, searchOutline, documentTextOutline,
} from 'ionicons/icons';
import { useAuthStore } from '@/stores/authStore';

const router = useRouter();
const authStore = useAuthStore();
const user = computed(() => authStore.user);
const isConductor = computed(() => user.value?.role === 'conductor');
const userInitial = computed(() => user.value?.name?.charAt(0).toUpperCase() || '?');

// Clave única por usuario — se calcula una sola vez al montar
const userId = authStore.user?.id || 'guest';
const k = (key: string) => `user_${userId}_${key}`;

const profilePhoto = ref<string | null>(localStorage.getItem(k('profilePhoto')));
const photoInput = ref<HTMLInputElement | null>(null);
function triggerPhotoUpload() { photoInput.value?.click(); }
function onPhotoChange(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    profilePhoto.value = ev.target?.result as string;
    localStorage.setItem(k('profilePhoto'), profilePhoto.value);
  };
  reader.readAsDataURL(file);
}

const bio = ref(localStorage.getItem(k('bio')) || '');
const editingBio = ref(false);
function saveBio() { editingBio.value = false; localStorage.setItem(k('bio'), bio.value); }

// Horas cada 30 min de 5:00 AM a 10:00 PM
const horas = (() => {
  const list = [];
  for (let h = 5; h <= 22; h++) {
    const ampm = h < 12 ? 'AM' : 'PM';
    const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
    list.push(`${h12}:00 ${ampm}`);
    if (h < 22) list.push(`${h12}:30 ${ampm}`);
  }
  return list;
})();

const dias = [
  { key: 'lunes', label: 'Lunes' },
  { key: 'martes', label: 'Martes' },
  { key: 'miercoles', label: 'Miércoles' },
  { key: 'jueves', label: 'Jueves' },
  { key: 'viernes', label: 'Viernes' },
  { key: 'sabado', label: 'Sábado' },
  { key: 'domingo', label: 'Domingo' },
];

const defaultSchedule = () => Object.fromEntries(dias.map(d => [d.key, { ida: '', vuelta: '' }]));
const schedule = ref({ ...defaultSchedule(), ...(JSON.parse(localStorage.getItem(k('schedule')) || 'null') || {}) });
async function saveSchedule() {
  localStorage.setItem(k('schedule'), JSON.stringify(schedule.value));
  await syncHorarioDB();
}

const defaultRoutes = () => Object.fromEntries(dias.map(d => [d.key, { stops: ['', ''], coords: [] }]));
const defaultPrecio = () => Object.fromEntries(dias.map(d => [d.key, '']));
const precio = ref({ ...defaultPrecio(), ...(JSON.parse(localStorage.getItem(k('precio')) || 'null') || {}) });
const routes = ref({ ...defaultRoutes(), ...(JSON.parse(localStorage.getItem(k('routes')) || 'null') || {}) });
function addStop(diaKey: string) { routes.value[diaKey].stops.splice(routes.value[diaKey].stops.length - 1, 0, ''); }
function removeStop(diaKey: string, i: number) { routes.value[diaKey].stops.splice(i, 1); }
async function saveRoutes() {
  localStorage.setItem(k('routes'), JSON.stringify(routes.value));
  localStorage.setItem(k('precio'), JSON.stringify(precio.value));
  await syncHorarioDB();
}

async function syncHorarioDB() {
  try {
    const token = localStorage.getItem('token');
    if (!token) { console.warn('syncHorarioDB: no token'); return; }
    console.log('Sincronizando horario...', schedule.value);
    const res = await fetch('https://gotogether-api.onrender.com/api/horarios', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ schedule: schedule.value, routes: routes.value, precio: precio.value }),
    });
    const data = await res.json();
    console.log('Horario sincronizado:', data);
  } catch (e) { console.error('Error sincronizando horario:', e); }
}

// Cargar horario desde la DB al iniciar
async function loadHorarioDB() {
  try {
    const token = localStorage.getItem('token');
    if (!token) return;
    const res = await fetch('https://gotogether-api.onrender.com/api/horarios/me', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) return;
    const data = await res.json();
    if (data.schedule && Object.keys(data.schedule).length > 0) {
      schedule.value = { ...defaultSchedule(), ...data.schedule };
      localStorage.setItem(k('schedule'), JSON.stringify(schedule.value));
    }
    if (data.routes && Object.keys(data.routes).length > 0) {
      routes.value = { ...defaultRoutes(), ...data.routes };
      localStorage.setItem(k('routes'), JSON.stringify(routes.value));
    }
    if (data.precio && Object.keys(data.precio).length > 0) {
      precio.value = { ...defaultPrecio(), ...data.precio };
      localStorage.setItem(k('precio'), JSON.stringify(precio.value));
    }
  } catch (e) { console.error('Error cargando horario:', e); }
}

onMounted(loadHorarioDB);

const savedDia = ref('');
async function autoSave(diaKey: string) {
  await saveSchedule();
  savedDia.value = diaKey;
  setTimeout(() => { savedDia.value = ''; }, 1500);
}
async function saveAndClose(tab: string, key: string) {
  if (tab === 'schedule') await saveSchedule();
  else await saveRoutes();
  savedDia.value = key;
  setTimeout(() => {
    (openDias as any)[tab][key] = false;
    savedDia.value = '';
  }, 800);
}

// Recargar datos si el usuario cambia
watch(user, () => {
  profilePhoto.value = localStorage.getItem(k('profilePhoto'));
  bio.value = localStorage.getItem(k('bio')) || '';
  schedule.value = JSON.parse(localStorage.getItem(k('schedule')) || 'null') || defaultSchedule();
  routes.value = JSON.parse(localStorage.getItem(k('routes')) || 'null') || defaultRoutes();
});

const openDias = reactive({
  schedule: Object.fromEntries(dias.map(d => [d.key, false])),
  route: Object.fromEntries(dias.map(d => [d.key, false])),
});
function toggleDia(tab: string, key: string) {
  (openDias as any)[tab][key] = !(openDias as any)[tab][key];
}

const reviews = ref<{name: string; rating: number; comment: string}[]>([]);
const avgRating = computed(() => {
  if (!reviews.value.length) return null;
  return (reviews.value.reduce((a, r) => a + r.rating, 0) / reviews.value.length).toFixed(1);
});

const tabs = computed(() => {
  const base = [
    { id: 'info', label: 'Info', icon: personOutline },
    { id: 'schedule', label: 'Horarios', icon: timeOutline },
  ];
  if (isConductor.value) {
    base.push({ id: 'route', label: 'Ruta', icon: mapOutline });
    base.push({ id: 'reviews', label: 'Reseñas', icon: starOutline });
  }
  return base;
});
const activeTab = ref('info');

function handleLogout() { authStore.logout(); router.replace('/welcome'); }
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');

.home-content { --background: #070707; font-family: 'DM Sans', sans-serif; }
.grain { position: fixed; inset: 0; background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)' opacity='0.04'/%3E%3C/svg%3E"); pointer-events: none; z-index: 0; }
.atm-glow { position: fixed; width: 300px; height: 300px; background: radial-gradient(circle, rgba(139,26,26,0.14) 0%, transparent 70%); top: -80px; left: 50%; transform: translateX(-50%); filter: blur(50px); pointer-events: none; z-index: 0; }

.top-bar { position: relative; z-index: 1; display: flex; justify-content: space-between; align-items: center; padding: 18px 22px 0; }
.brand-name { font-family: 'Outfit', sans-serif; font-size: 18px; font-weight: 800; letter-spacing: -0.5px; }
.go { color: #ede9e6; } .tog { color: #a32020; }
.icon-btn { width: 34px; height: 34px; background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: rgba(237,233,230,0.45); font-size: 17px; cursor: pointer; }

.profile-hero { position: relative; z-index: 1; padding: 20px 22px 16px; display: flex; align-items: center; gap: 22px; }
.avatar-wrap { position: relative; flex-shrink: 0; cursor: pointer; }
.avatar-img { width: 68px; height: 68px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(139,26,26,0.4); }
.avatar { width: 68px; height: 68px; border-radius: 50%; background: linear-gradient(135deg, #8B1A1A 0%, #4a0e0e 100%); display: flex; align-items: center; justify-content: center; font-family: 'Outfit', sans-serif; font-size: 26px; font-weight: 800; color: #ede9e6; box-shadow: 0 0 28px rgba(139,26,26,0.3); }
.avatar-badge { position: absolute; bottom: -2px; right: -2px; width: 22px; height: 22px; background: #171717; border: 1.5px solid rgba(255,255,255,0.12); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; color: rgba(237,233,230,0.5); }
.stats-row { display: flex; gap: 20px; }
.stat { display: flex; flex-direction: column; align-items: center; }
.stat-n { font-family: 'Outfit', sans-serif; font-size: 17px; font-weight: 800; color: #ede9e6; }
.stat-l { color: rgba(237,233,230,0.3); font-size: 9px; font-weight: 500; letter-spacing: 0.5px; text-transform: uppercase; }

.profile-meta { position: relative; z-index: 1; padding: 0 22px 16px; }
.meta-name-row { display: flex; align-items: center; gap: 10px; margin-bottom: 5px; }
.meta-name { font-family: 'Outfit', sans-serif; font-size: 17px; font-weight: 700; letter-spacing: -0.3px; color: #ede9e6; }
.badge { display: inline-flex; align-items: center; gap: 5px; border-radius: 20px; padding: 3px 10px; font-size: 10px; font-weight: 600; font-family: 'DM Sans', sans-serif; }
.badge ion-icon { font-size: 10px; }
.badge-red { background: rgba(139,26,26,0.14); border: 1px solid rgba(139,26,26,0.28); color: #a32020; }
.badge-gray { background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.12); color: rgba(237,233,230,0.6); }
.meta-city { color: rgba(237,233,230,0.35); font-size: 12px; margin-bottom: 10px; display: flex; align-items: center; gap: 5px; }
.meta-city ion-icon { font-size: 12px; }
.bio-wrap { display: flex; align-items: flex-start; gap: 6px; cursor: pointer; margin-bottom: 12px; }
.bio-text { color: rgba(237,233,230,0.5); font-size: 13px; line-height: 1.55; flex: 1; }
.bio-edit-icon { color: rgba(237,233,230,0.2); font-size: 13px; flex-shrink: 0; margin-top: 2px; }
.bio-edit textarea { width: 100%; background: #171717; border: 1px solid rgba(139,26,26,0.3); border-radius: 12px; color: #ede9e6; font-family: 'DM Sans', sans-serif; font-size: 13px; padding: 12px 14px; resize: none; outline: none; box-sizing: border-box; margin-bottom: 12px; }
.edit-profile-btn { width: 100%; padding: 10px; background: transparent; border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; color: #ede9e6; font-family: 'Outfit', sans-serif; font-size: 13px; font-weight: 600; cursor: pointer; }

.tabs { position: relative; z-index: 1; display: flex; border-top: 1px solid rgba(255,255,255,0.06); border-bottom: 1px solid rgba(255,255,255,0.06); }
.tab { flex: 1; padding: 11px 4px; display: flex; flex-direction: column; align-items: center; gap: 4px; color: rgba(237,233,230,0.25); font-size: 9px; font-weight: 600; font-family: 'DM Sans', sans-serif; letter-spacing: 0.8px; text-transform: uppercase; border: none; background: transparent; border-bottom: 2px solid transparent; cursor: pointer; transition: color 0.2s, border-color 0.2s; }
.tab ion-icon { font-size: 16px; }
.tab.on { color: #a32020; border-bottom-color: #8B1A1A; }

.tab-content { position: relative; z-index: 1; padding: 16px 20px 48px; display: flex; flex-direction: column; gap: 8px; }

.info-card { background: #111111; border: 1px solid rgba(255,255,255,0.06); border-radius: 16px; overflow: hidden; }
.info-row { display: flex; align-items: center; gap: 14px; padding: 12px 16px; border-bottom: 1px solid rgba(255,255,255,0.04); }
.info-row:last-child { border-bottom: none; }
.info-icon-wrap { width: 30px; height: 30px; background: #1a1a1a; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 15px; color: #a32020; flex-shrink: 0; }
.info-col { display: flex; flex-direction: column; }
.info-lbl { color: rgba(237,233,230,0.28); font-size: 9px; font-weight: 600; letter-spacing: 0.8px; text-transform: uppercase; }
.info-val { color: #ede9e6; font-size: 13px; font-weight: 500; margin-top: 1px; }

/* Day cards */
.day-card { background: #111111; border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; overflow: hidden; }
.day-card-header { width: 100%; display: flex; align-items: center; gap: 10px; padding: 14px 16px; background: transparent; border: none; cursor: pointer; }
.day-name { font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 700; color: #ede9e6; min-width: 72px; text-align: left; }
.day-chips { display: flex; gap: 6px; flex: 1; flex-wrap: wrap; }
.day-chip { background: rgba(139,26,26,0.15); border: 1px solid rgba(139,26,26,0.25); border-radius: 6px; color: #a32020; font-size: 10px; font-weight: 600; padding: 2px 8px; font-family: 'DM Sans', sans-serif; }
.day-chevron { color: rgba(237,233,230,0.25); font-size: 16px; flex-shrink: 0; }
.day-card-body { padding: 0 16px 14px; border-top: 1px solid rgba(255,255,255,0.04); }
.day-field-row { display: flex; gap: 10px; margin-top: 12px; }
.day-field { display: flex; flex-direction: column; gap: 6px; flex: 1; }
.day-field-label { color: rgba(237,233,230,0.28); font-size: 9px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
.schedule-day-input { background: #1a1a1a; border: 1px solid rgba(255,255,255,0.07); border-radius: 8px; color: #ede9e6; font-family: 'DM Sans', sans-serif; font-size: 13px; padding: 9px 12px; outline: none; width: 100%; }
.schedule-day-input::placeholder { color: rgba(237,233,230,0.18); font-size: 11px; }

/* Vehicle */
.vehicle-card { display: flex; align-items: center; gap: 14px; background: #111111; border: 1px solid rgba(255,255,255,0.06); border-radius: 16px; padding: 16px; }
.vehicle-icon-wrap { width: 44px; height: 44px; background: rgba(139,26,26,0.12); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: #a32020; flex-shrink: 0; }
.vehicle-info { display: flex; flex-direction: column; }
.vehicle-model { color: #ede9e6; font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 700; }
.vehicle-sub { color: rgba(237,233,230,0.35); font-size: 11px; margin-top: 2px; }

/* Stops */
.stops-list { display: flex; flex-direction: column; gap: 8px; margin-top: 12px; }
.stop-row { display: flex; align-items: center; gap: 10px; }
.stop-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.stop-dot.start { background: #8B1A1A; box-shadow: 0 0 8px rgba(139,26,26,0.5); }
.stop-dot.mid { background: rgba(255,255,255,0.2); border: 2px solid rgba(255,255,255,0.15); }
.stop-dot.end { background: rgba(237,233,230,0.5); }
.stop-input { flex: 1; background: #1a1a1a; border: 1px solid rgba(255,255,255,0.07); border-radius: 8px; color: #ede9e6; font-family: 'DM Sans', sans-serif; font-size: 13px; padding: 9px 12px; outline: none; }
.stop-input::placeholder { color: rgba(237,233,230,0.18); }
.btn-remove { background: rgba(255,60,60,0.08); border: none; border-radius: 6px; color: rgba(255,100,100,0.6); font-size: 15px; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; flex-shrink: 0; }

.day-actions { display: flex; gap: 8px; margin-top: 10px; }
.btn-add { background: rgba(139,26,26,0.12); border: 1px solid rgba(139,26,26,0.25); border-radius: 8px; color: #a32020; font-family: 'DM Sans', sans-serif; font-size: 12px; font-weight: 600; padding: 7px 12px; cursor: pointer; display: flex; align-items: center; gap: 4px; }
.btn-save-sm { display: flex; align-items: center; gap: 5px; background: #8B1A1A; border: none; border-radius: 8px; color: #ede9e6; font-family: 'Outfit', sans-serif; font-size: 12px; font-weight: 600; padding: 7px 14px; cursor: pointer; box-shadow: 0 4px 12px rgba(139,26,26,0.3); transition: background 0.3s; }
.btn-save-sm.saved { background: #1a6b1a; box-shadow: 0 4px 12px rgba(26,107,26,0.3); }
.precio-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; border-top: 1px solid rgba(255,255,255,0.05); }
.precio-label { display: flex; align-items: center; gap: 6px; font-size: 12px; color: rgba(237,233,230,0.45); font-family: 'DM Sans', sans-serif; }
.precio-input-wrap { display: flex; align-items: center; gap: 4px; background: #1a1a1a; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 6px 10px; }
.precio-currency { color: #4caf50; font-weight: 700; font-size: 13px; }
.precio-input { background: transparent; border: none; outline: none; color: #ede9e6; font-family: 'Outfit', sans-serif; font-size: 14px; font-weight: 700; width: 70px; text-align: right; }

.schedule-hint { color: rgba(237,233,230,0.3); font-size: 11.5px; padding: 0 16px 12px; font-family: 'DM Sans', sans-serif; }

.day-chip.empty { color: rgba(237,233,230,0.2); background: transparent; border-color: rgba(255,255,255,0.05); }

.time-select {
  width: 100%; background: #1a1a1a; border: 1px solid rgba(255,255,255,0.1);
  border-radius: 10px; padding: 10px 12px; color: #ede9e6;
  font-family: 'DM Sans', sans-serif; font-size: 13px;
  outline: none; cursor: pointer; appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='rgba(237,233,230,0.3)' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
  background-repeat: no-repeat; background-position: right 10px center;
}
.time-select:focus { border-color: rgba(139,26,26,0.5); }
.time-select option { background: #1a1a1a; color: #ede9e6; }

.save-indicator {
  display: flex; align-items: center; gap: 6px;
  color: #25d366; font-size: 12px; font-weight: 600;
  font-family: 'Outfit', sans-serif; padding: 6px 0 0;
  opacity: 0; transition: opacity 0.3s ease;
}
.save-indicator.visible { opacity: 1; }

.empty-state { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 28px 0; color: rgba(237,233,230,0.25); }
.empty-icon { font-size: 32px; }

.bottom-nav {
  position: fixed; bottom: 0; left: 0; right: 0; z-index: 100;
  background: rgba(7,7,7,0.96); backdrop-filter: blur(20px);
  border-top: 1px solid rgba(255,255,255,0.07);
  display: flex; padding: 10px 0 20px;
}
.nav-item {
  flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px;
  font-family: 'DM Sans', sans-serif; font-size: 9px; font-weight: 600;
  letter-spacing: 0.5px; text-transform: uppercase;
  color: rgba(237,233,230,0.22); cursor: pointer; border: none; background: transparent;
}
.nav-item ion-icon { font-size: 20px; }
.nav-item.active { color: #a32020; }
.nav-dot { width: 4px; height: 4px; border-radius: 50%; background: #a32020; margin-top: -2px; }
</style>


