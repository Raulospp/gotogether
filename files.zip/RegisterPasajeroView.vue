<template>
  <ion-page>
    <ion-content :fullscreen="true" class="register-content">

      <div class="bg-glow bg-glow-top"></div>

      <div class="register-wrapper">

        <!-- Back -->
        <button class="back-btn" @click="$router.back()">
          <ion-icon :icon="chevronBackOutline" />
        </button>

        <!-- Título -->
        <h1 class="page-title">
          REGISTRO – <span class="title-accent">PASAJERO</span>
        </h1>

        <!-- Formulario -->
        <div class="form-card">

          <div class="field-group">
            <label>Nombre completo</label>
            <div class="input-wrap" :class="{ focused: focused === 'name' }">
              <input
                v-model="form.name"
                type="text"
                placeholder="Tu nombre completo"
                @focus="focused = 'name'"
                @blur="focused = ''"
              />
            </div>
          </div>

          <div class="field-group">
            <label>Ciudad</label>
            <div class="select-wrap" :class="{ focused: focused === 'city' }">
              <select v-model="form.city" @focus="focused = 'city'" @blur="focused = ''">
                <option value="">Selecciona ciudad</option>
                <option>Univalle</option>
                <option>Javeriana</option>
                <option>ICESI</option>
                <option>UAO</option>
                <option>San Buenaventura</option>
              </select>
              <ion-icon :icon="chevronDownOutline" class="select-arrow" />
            </div>
          </div>

          <div class="field-group">
            <label>Ruta / Universidad</label>
            <div class="select-wrap" :class="{ focused: focused === 'university' }">
              <select v-model="form.university" @focus="focused = 'university'" @blur="focused = ''">
                <option value="">Selecciona universidad</option>
                <option>Sur ~ Univalle</option>
                <option>Norte ~ Javeriana</option>
                <option>Centro ~ ICESI</option>
                <option>Oeste ~ UAO</option>
              </select>
              <ion-icon :icon="chevronDownOutline" class="select-arrow" />
            </div>
          </div>

          <div class="field-group">
            <label>Preferimo.zel riate</label>
            <div class="select-wrap" :class="{ focused: focused === 'time' }">
              <select v-model="form.time" @focus="focused = 'time'" @blur="focused = ''">
                <option value="">Selecciona horario</option>
                <option>Hora: 06:00 AM</option>
                <option>Hora: 06:30 AM</option>
                <option>Hora: 07:00 AM</option>
                <option>Hora: 07:30 AM</option>
                <option>Hora: 08:00 AM</option>
              </select>
              <ion-icon :icon="chevronDownOutline" class="select-arrow" />
            </div>
          </div>

          <!-- Error -->
          <div v-if="error" class="error-msg">
            <ion-icon :icon="alertCircleOutline" /> {{ error }}
          </div>

          <button class="btn-submit" :disabled="loading" @click="handleSubmit">
            <ion-spinner v-if="loading" name="crescent" />
            <span v-else>Registrarme</span>
          </button>

          <button class="btn-cancel" @click="$router.back()">Cancelar</button>

        </div>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { IonPage, IonContent, IonIcon, IonSpinner } from '@ionic/vue';
import { chevronBackOutline, chevronDownOutline, alertCircleOutline } from 'ionicons/icons';
import { useAuthStore } from '@/stores/authStore';

const router = useRouter();
const authStore = useAuthStore();
const loading = ref(false);
const error = ref('');
const focused = ref('');

const form = ref({ name: '', city: '', university: '', time: '' });

async function handleSubmit() {
  const { name, city, university, time } = form.value;
  if (!name || !city || !university || !time) {
    error.value = 'Por favor completa todos los campos';
    return;
  }
  error.value = '';
  loading.value = true;
  try {
    await authStore.register(name, `${name.replace(/\s+/g,'').toLowerCase()}@gotogether.app`, 'pass123');
    router.replace('/home');
  } catch (e: any) {
    error.value = e?.message || 'Error al registrarse';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Exo+2:wght@400;600;700;800;900&display=swap');

.register-content {
  --background: #12082a;
  font-family: 'Exo 2', sans-serif;
}

.bg-glow-top {
  position: fixed;
  width: 300px; height: 300px;
  background: radial-gradient(circle, rgba(65, 88, 208, 0.3), transparent 70%);
  filter: blur(60px);
  top: -80px; left: -60px;
  pointer-events: none; z-index: 0;
}

.register-wrapper {
  position: relative; z-index: 1;
  padding: 20px 22px 40px;
  min-height: 100vh;
  display: flex; flex-direction: column;
}

.back-btn {
  background: rgba(255,255,255,0.07);
  border: none; border-radius: 10px;
  width: 38px; height: 38px;
  color: #fff; font-size: 20px;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  margin-bottom: 20px;
  align-self: flex-start;
}

.page-title {
  font-size: 22px; font-weight: 900;
  color: #fff; letter-spacing: 1px;
  margin: 0 0 24px;
  text-transform: uppercase;
}

.title-accent {
  background: linear-gradient(90deg, #4158d0, #6a7de8);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.form-card { display: flex; flex-direction: column; gap: 14px; }

.field-group label {
  display: block;
  color: rgba(255,255,255,0.75);
  font-size: 13px; font-weight: 600;
  margin-bottom: 6px; letter-spacing: 0.3px;
}

.input-wrap,
.select-wrap {
  background: rgba(255,255,255,0.07);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  transition: border-color 0.2s, box-shadow 0.2s;
  position: relative;
}

.input-wrap.focused, .select-wrap.focused {
  border-color: #4158d0;
  box-shadow: 0 0 0 3px rgba(65, 88, 208, 0.2);
}

.input-wrap input, .select-wrap select {
  width: 100%; background: transparent; border: none; outline: none;
  color: #fff; font-family: 'Exo 2', sans-serif;
  font-size: 14px; padding: 13px 14px;
  box-sizing: border-box; -webkit-appearance: none; appearance: none;
}

.input-wrap input::placeholder { color: rgba(255,255,255,0.22); }
.select-wrap select option { background: #1e1040; color: #fff; }

.select-arrow {
  position: absolute; right: 12px; top: 50%;
  transform: translateY(-50%);
  color: rgba(255,255,255,0.4); font-size: 16px; pointer-events: none;
}

.error-msg {
  display: flex; align-items: center; gap: 8px;
  background: rgba(255,80,80,0.1); border: 1px solid rgba(255,80,80,0.25);
  color: #ff7070; border-radius: 8px; padding: 10px 14px; font-size: 13px;
}

.btn-submit {
  width: 100%; padding: 15px;
  background: linear-gradient(135deg, #4158d0, #2d3db0);
  border: none; border-radius: 12px; color: #fff;
  font-family: 'Exo 2', sans-serif;
  font-size: 16px; font-weight: 700;
  cursor: pointer; display: flex; align-items: center; justify-content: center;
  box-shadow: 0 6px 24px rgba(65, 88, 208, 0.45);
  transition: transform 0.15s; margin-top: 6px;
}
.btn-submit:active { transform: scale(0.97); }
.btn-submit:disabled { opacity: 0.5; cursor: not-allowed; }

.btn-cancel {
  background: transparent; border: none;
  color: rgba(255,255,255,0.45);
  font-family: 'Exo 2', sans-serif;
  font-size: 14px; font-weight: 600;
  cursor: pointer; padding: 8px; text-align: center;
}
</style>
