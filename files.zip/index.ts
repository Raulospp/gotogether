// src/router/index.ts
import { createRouter, createWebHistory } from '@ionic/vue-router';
import { RouteRecordRaw } from 'vue-router';
import { authService } from '@/services/authService';

const routes: Array<RouteRecordRaw> = [
  { path: '/', redirect: '/welcome' },
  { path: '/welcome',            component: () => import('@/views/WelcomeView.vue') },
  { path: '/register/conductor', component: () => import('@/views/RegisterConductorView.vue') },
  { path: '/register/pasajero',  component: () => import('@/views/RegisterPasajeroView.vue') },
  {
    path: '/home',
    component: () => import('@/views/HomeView.vue'),
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

// Guard de autenticación
router.beforeEach((to, _from, next) => {
  if (to.meta.requiresAuth && !authService.isAuthenticated()) {
    next('/welcome');
  } else {
    next();
  }
});

export default router;
